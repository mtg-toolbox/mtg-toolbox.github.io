#include "shared_plugin_helpers.h"

#include "ProcessorBase/ProcessorBase.cpp"