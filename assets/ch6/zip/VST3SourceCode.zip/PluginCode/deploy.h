
#pragma once

#include "Source/DeploymentThreads/DeploymentThread.h"

class PluginDeploymentThread: public DeploymentThread {
public:
    // initialize your deployment thread here
    PluginDeploymentThread():DeploymentThread() {
        // keep track of the initially randomized latent vectors for preset saving
        CustomPresetData->tensor("latent_A", latent_A);
        CustomPresetData->tensor("latent_B", latent_B);

    }

    // this method runs on a per-event basis.
    // the majority of the deployment will be done here!
    std::pair<bool, bool> deploy (
        std::optional<MidiFileEvent> & new_midi_event_dragdrop,
        std::optional<EventFromHost> & new_event_from_host,
        bool gui_params_changed_since_last_call,
        bool new_preset_loaded_since_last_call,
        bool new_midi_file_dropped_on_visualizers,
        bool new_audio_file_dropped_on_visualizers) override {

        /*if (gui_params_changed_since_last_call)
        {
            gui_params.print();
        }*/

        // Try loading the model if it hasn't been loaded yet
        if (!isModelLoaded) {
            load("drumLoopVAE.pt");
        }

        // main deployment logic
        if (isModelLoaded) {
            // check if a new preset was loaded and update the tensors accordingly
            auto new_presets_loaded = new_preset_loaded_since_last_call ? loadTensorsFromPreset() : false;

            // update groove if new host event is available
            auto groove_just_updated =
                grooveUpdated(new_event_from_host, new_presets_loaded);
            groove_has_been_updated = groove_has_been_updated || groove_just_updated;

            // re-encode the groove
            auto finished_encoding_groove = false;
            if (groove_has_been_updated) {
                finished_encoding_groove = encodeGroove();
                if (finished_encoding_groove) {
                    groove_has_been_updated = false; // reset the flag
                }
            }

            // re-calculate the playback latent_vector if any of the above changed
            auto latents_changed = updateLatents(new_presets_loaded, finished_encoding_groove);

            // update the voice mapping
            auto voice_mapping_changed = updateVoiceMapping();

            // per voice threshold and max counts changed
            auto sampling_params_changed = updatePerVoiceSamplingParams();

            // check if temperature changed
            auto temperature_changed = checkTemperature();

            // generate the pattern
            if (latents_changed || sampling_params_changed || temperature_changed) {
                decodeLatent(latent_vector, playback_hits, playback_velocities, playback_offsets);
            }

            // update per voice velocity scaling mask
            auto generation_velocity_mask_updated = updateVelocityScalingMask();

            // prepare the playback sequence and policy
            if (latents_changed || voice_mapping_changed ||
                sampling_params_changed || generation_velocity_mask_updated ||
                temperature_changed) {

                if (generation_velocity_mask_updated || sampling_params_changed || temperature_changed) {
                    // update A, B, Groove Displays
                    updateAllDisplayPatterns();
                }

                preparePlaybackSequence();
                preparePlaybackPolicy();

                return {true, true};
            }

        }

        // your implementation goes here
        return {false, false};
    }

private:
    // Playhead position, record/ overdub states
    double phead = -1.0f; // the actual playhead position
    int phead_step = -1; // step index corresponding to the playhead
    float memory_2bars = 0;
    bool adaptive_groove_density = false;
    bool groove_has_been_updated = false;
    double last_generation_phead = -2.0f;
    int responsiveness = 0;

    // AB Interpolation Parameters
    torch::Tensor latent_A = torch::randn({ 1, 128 });
    torch::Tensor latent_B = torch::randn({ 1, 128 });
    torch::Tensor latent_g = torch::randn({ 1, 128 });
    torch::Tensor latent_vector = torch::randn({ 1, 128 });
    double interpolate_slider_value = 0.0;
    double follow_slider_value = 0.0;
    double density = 0.5;

    // add any member variables or methods you need here
    torch::Tensor voice_thresholds = torch::ones({ 9 }, torch::kFloat32) * 0.5f;
    torch::Tensor max_counts_allowed = torch::ones({ 9 }, torch::kFloat32) * 32;
    int sampling_mode = 0;
    float temperature = 1.0f;
    std::map<int, int> voiceMap;

    // Velocity Mask
    torch::Tensor velocity_mask = torch::ones({ 1, 32, 9}, torch::kFloat32) * 1.0f;

    // following will be used for the inference
    torch::Tensor groove_hits = torch::zeros({1, 32, 1}, torch::kFloat32);
    torch::Tensor groove_velocities = torch::zeros({1, 32, 1}, torch::kFloat32);
    torch::Tensor groove_offsets = torch::zeros({1, 32, 1}, torch::kFloat32);
    torch::Tensor groove_hit_registrations = torch::ones({1, 32, 1}, torch::kFloat32) * -1.0f; // ppq at which the hit was registered
    double vel_scaler_val = 0.5f;
    double off_quantizer_val = 0.0f;
    double generation_off_quantizer_val = 0.0f;
    double groove_inversion = 0.0f;

    // scaled groove for inference
    torch::Tensor groove_hvo_scaled = torch::zeros({1, 32, 27}, torch::kFloat32);
    torch::Tensor groove_velocities_scaled = torch::zeros({1, 32, 1}, torch::kFloat32);
    torch::Tensor groove_offsets_scaled = torch::zeros({1, 32, 1}, torch::kFloat32);

    torch::Tensor playback_hits = torch::zeros({1, 32, 9}, torch::kFloat32);
    torch::Tensor playback_velocities = torch::zeros({1, 32, 9}, torch::kFloat32);
    torch::Tensor playback_offsets = torch::zeros({1, 32, 9}, torch::kFloat32);

    // voice map for visualization purposes only
    map<int, int> display_voice_maps = {
        {0, 36}, {1, 38}, {2, 42},
        {3, 46}, {4, 41}, {5, 48},
        {6, 45}, {7, 49}, {8, 51}
    };

    // temporary hit, velocity, offset tensors for visualization
    torch::Tensor display_hits;
    torch::Tensor display_velocities;
    torch::Tensor display_offsets;
    torch::Tensor display_offsets_scaled;


    // load the tensors from the preset
    bool loadTensorsFromPreset() {
        bool loaded = false;
        auto A = CustomPresetData->tensor("latent_A");
        if (A != std::nullopt)
        {
            latent_A = *A;
            loaded = true;
            displayPatternAt(latent_A, "MidiVisualizerA");
        }
        auto B = CustomPresetData->tensor("latent_B");
        if (B != std::nullopt)
        {
            latent_B = *B;
            loaded = true;
            displayPatternAt(latent_B, "MidiVisualizerB");
        }
        auto g = CustomPresetData->tensor("latent_g");
        if (g != std::nullopt)
        {
            latent_g = *g;
            loaded = true;
            displayPatternAt(latent_g, "MidiVisualizerGroove2Drum");
        }
        auto groove_hits_ = CustomPresetData->tensor("groove_hits");
        if (groove_hits_ != std::nullopt)
        {
            groove_hits = *groove_hits_;
            loaded = true;
        }
        auto groove_velocities_ = CustomPresetData->tensor("groove_velocities");
        if (groove_velocities_ != std::nullopt)
        {
            groove_velocities = *groove_velocities_;
            loaded = true;
        }
        auto groove_offsets_ = CustomPresetData->tensor("groove_offsets");
        if (groove_offsets_ != std::nullopt)
        {
            groove_offsets = *groove_offsets_;
            loaded = true;
        }

        return loaded;
    }

    // checks if a new host event has been received and
    // updates the input tensor accordingly
    // returns true if groove is to be re-encoded
    bool grooveUpdated(std::optional<EventFromHost> & new_event, bool new_preset) {

        bool groove_changed = false;
        bool density_changed = false;

        // Check responsiveness
        responsiveness = (int)gui_params.getValueFor("Responsiveness") * 4;

        // get the record/overdub states
        bool RecordOn = gui_params.isToggleButtonOn("Record");

        if (gui_params.wasParamUpdated("Memory")) {
            auto mem = (float)gui_params.getValueFor("Memory");
            if (mem < 0.02) {
                memory_2bars = 0.0f; // forgets everything as soon as re-entered
            } else if (mem < 0.1) {
                memory_2bars = 8.0f; // 8 ppq = 2 bars of memory
            } else if (mem < 0.95f) {
                memory_2bars = (float(int(mem/0.05)) * 8.0f); // up to 18 2-bar repeats
            } else {
                memory_2bars = 1000000.0f; // infinite memory
            }
        }

        // get interpolate density value if changed
        if (gui_params.wasParamUpdated("Density")) {
            auto den = gui_params.getValueFor("Density");
            if (den != density) {
                // if manually moved, disable adaptive density button
                density = gui_params.getValueFor("Density");
                density_changed = true;
            }
        }

        // check if groove is to be cleared
        if (gui_params.wasButtonClicked("Clear Groove")) {
            // auto enable adaptive density
            gui_params.setValueFor("Adaptive Density", 1.0f);
            adaptive_groove_density = true;
            density = 0.0f;
            gui_params.setValueFor("Density", density);

            // clear the groove
            groove_hits = torch::zeros({1, 32, 1}, torch::kFloat32);
            groove_velocities = torch::zeros({1, 32, 1}, torch::kFloat32);
            groove_offsets = torch::zeros({1, 32, 1}, torch::kFloat32);
            midiVisualizersData->clear_visualizer_data("MidiVisualizerGroove");
            groove_changed = true;
        }

        // check if density is changed
        if (gui_params.wasParamUpdated("Adaptive Density")) {
            adaptive_groove_density = gui_params.getValueFor("Adaptive Density") > 0.5f;
            if (adaptive_groove_density) {
                density = groove_hits.sum().item<float>() / 32.0f;
                gui_params.setValueFor("Density", density);
            }
            density_changed = true;
        }

        // get the groove information from the host event
        if (gui_params.wasParamUpdated("Groove Velocity")) {
            vel_scaler_val = gui_params.getValueFor("Groove Velocity");
            groove_changed = true;
        }

        if (gui_params.wasParamUpdated("Groove Offset")) {
            off_quantizer_val = gui_params.getValueFor("Groove Offset");
            groove_changed = true;
        }

        if (gui_params.wasParamUpdated("Groove Invert")) {
            groove_inversion = gui_params.getValueFor("Groove Invert");
            groove_changed = true;
        }

        // if new event, process based on parameters
        if (new_event != std::nullopt) {
            // get the playhead position
            if (new_event != std::nullopt) {
                if (new_event->isFirstBufferEvent() || new_event->isPlaybackStoppedEvent()) {
                    last_generation_phead = -2; // reset playhead
                }

                if (new_event->isNewBufferEvent()) {
                    auto new_phead = new_event->Time().inQuarterNotes();

                    // clear step as soon as entered if record on but not overdub
                    if (RecordOn) {
                        auto new_phead_step = mapPPQToTimeStep(new_phead);
                        if (new_phead_step - phead_step) {
                            phead_step = new_phead_step;
                            if (std::abs(phead - groove_hit_registrations[0][phead_step][0].item<float>()) >= memory_2bars) {
                                if (groove_hits[0][phead_step][0].item<float>() > 0) {
                                    groove_hits[0][phead_step][0] = 0;
                                    groove_velocities[0][phead_step][0] = 0;
                                    groove_offsets[0][phead_step][0] = 0;
                                    groove_hit_registrations[0][phead_step][0] = -1.0f;
                                    groove_changed = true;
                                }
                            }
                        }
                        phead_step = new_phead_step;
                    }
                    phead = new_phead;
                }
            }

            if (new_event->isNoteOnEvent() && RecordOn) {

                auto ppq  = new_event->Time().inQuarterNotes(); // time in ppq
                auto velocity = new_event->getVelocity(); // velocity
                auto div = round(ppq / .25f);
                auto offset = (ppq - (div * .25f)) / 0.125 * 0.5 ;
                auto grid_index = mapPPQToTimeStep(new_event->Time().inQuarterNotes());

                // check if louder if overlapping
                if (groove_hits[0][grid_index][0].item<float>() > 0 &&
                    std::abs(groove_hit_registrations[0][grid_index][0].item<float>() - phead) > 0.25) {
                    if (groove_velocities[0][grid_index][0].item<float>() < velocity ||
                        groove_offsets[0][grid_index][0].item<float>() != offset) {
                        groove_velocities[0][grid_index][0] = velocity;
                        groove_offsets[0][grid_index][0] = offset;
                        groove_hit_registrations[0][grid_index][0] = phead;
                        groove_changed = true;
                    }
                } else {
                    groove_hits[0][grid_index][0] = 1;
                    groove_velocities[0][grid_index][0] = velocity;
                    groove_offsets[0][grid_index][0] = offset;
                    groove_hit_registrations[0][grid_index][0] = phead;
                    groove_changed = true;
                }

            }

        }

        // scale the groove if new note or new groove params
        if (groove_changed || new_preset) {
            scaleGroove();

            // stack up the groove information into a single tensor
            groove_hvo_scaled = torch::concat(
                {
                    groove_hits,
                    groove_velocities_scaled,
                    groove_offsets_scaled
                }, 2);

            // ignore the operations (I'm just changing the formation of the tensor)
            groove_hvo_scaled = torch::zeros({1, 32, 27});
            groove_hvo_scaled.index_put_(
                {torch::indexing::Ellipsis, 2},
                groove_hits.index({torch::indexing::Ellipsis, 0}));
            groove_hvo_scaled.index_put_(
                {torch::indexing::Ellipsis, 11},
                groove_velocities_scaled.index({torch::indexing::Ellipsis, 0}));
            groove_hvo_scaled.index_put_(
                {torch::indexing::Ellipsis, 20},
                groove_offsets_scaled.index({torch::indexing::Ellipsis, 0}));
        }

        if (groove_changed) {
            // recalculate density if adaptive density is on
            if (adaptive_groove_density) {
                density = groove_hits.sum().item<float>() / 32.0f;
                gui_params.setValueFor("Density", density);
                density_changed = true;
            }
        }

        // re-encode the groove if groove changed or density changed or new preset
        if (groove_changed || density_changed || new_preset) {
            // track the groove
            // track the groove info
            CustomPresetData->tensor("groove_hits", groove_hits);
            CustomPresetData->tensor("groove_velocities", groove_velocities);
            CustomPresetData->tensor("groove_offsets", groove_offsets);
            displayGroove();

            return true;
        } else {
            return false;
        }
    }

    // encodes the groove into a latent vector using the encoder
    bool encodeGroove() {

        if (abs(phead - last_generation_phead) >= (responsiveness)) {
            if (responsiveness > 0 && fmod(int(phead), responsiveness) != 0.0f) {
                // ensure we only reencode at beats ze
                return false;
            }

            last_generation_phead = phead;
            // preparing the input to encode() method
            std::vector<torch::jit::IValue> enc_inputs;
            enc_inputs.emplace_back(groove_hvo_scaled);
            enc_inputs.emplace_back(torch::tensor(
                                        density,
                                        torch::kFloat32).unsqueeze_(0));

            // get the encode method
            auto encode = model.get_method("encode");

            // encode the input
            auto encoder_output = encode(enc_inputs);

            // get latent vector from encoder output
            latent_g = encoder_output.toTuple()->elements()[2].toTensor();
            CustomPresetData->tensor("latent_g", latent_g); // track the latent vector

            // display the groove
            displayPatternAt(latent_g, "MidiVisualizerGroove2Drum");
            return true;
        } else {
            return false;
        }

    }

    static float getMidPointOfVelocities(at::Tensor& t) {
        vector<float> v;
        for (int i = 0; i < 32; i++) {
            if (t[0][i][0].item<float>() > 0) {
                v.push_back(t[0][i][0].item<float>());
            }
        }
        if (v.size() < 1) {
            return -1.0f;
        } else {
            auto min = *std::min_element(v.begin(), v.end());
            auto max = *std::max_element(v.begin(), v.end());
            return (min + max) / 2.0f;
        }
    }

    // scales the groove according to the velocity and offset params
    void scaleGroove() {
        // scale the velocity

        // use distance from 1 and inverse exponentially apply gain
        // those closer to 1 will be slower to change
        // expand lower and upper ranges
        // scale using a sigmoid
        double mapped_slider_val;

        if (vel_scaler_val > 1) {
            mapped_slider_val = 1.0 + (vel_scaler_val - 1.0) * 2.0;
        } else {
            mapped_slider_val = vel_scaler_val / 2.0;
        }
        auto gain = 2.0 / (1.0 + exp(-(vel_scaler_val - 1)));

        groove_velocities_scaled = torch::pow(gain,
                                                  pow(0.8+abs(1.0 - groove_velocities), 3));
        groove_velocities_scaled = groove_velocities_scaled * groove_velocities;
        groove_velocities_scaled = torch::clamp(groove_velocities_scaled, 0.0f, 1.0f);

        // invert groove
        if (groove_inversion > 0) {
            // get non-zero velocity values
            auto non_zero_vels = torch::nonzero(groove_velocities_scaled);
            auto mid_point = getMidPointOfVelocities(groove_velocities_scaled);
            if (mid_point > 0) {
                groove_velocities_scaled = (mid_point - groove_velocities_scaled) * groove_inversion + groove_velocities_scaled;
            }
        }

        groove_offsets_scaled = groove_offsets * (1.0 - off_quantizer_val);
    }

    // update any variables that impact the latent vector
    bool updateLatents(bool new_preset, bool groove_re_encoded) {

        bool changed = false;

        // check if buttons were clicked to randomize the pattern
        auto ButtonATriggered = gui_params.wasButtonClicked("Random A");
        if (ButtonATriggered) {
            latent_A = torch::randn({ 1, 128 });
            CustomPresetData->tensor("latent_A", latent_A);
            displayPatternAt(latent_A, "MidiVisualizerA");
            changed = true;
            cout << "Random A Pressed" << endl;
        }

        // check if snap here button was clicked
        auto ButtonSnapHereTriggered = gui_params.wasButtonClicked("Snap To A");
        if (ButtonSnapHereTriggered) {
            latent_A = latent_vector;
            CustomPresetData->tensor("latent_A", latent_A);
            gui_params.setValueFor("Interpolate", 0.0f);
            gui_params.setValueFor("Follow", 0.0f);
            displayPatternAt(latent_A, "MidiVisualizerA");
            changed = true;
        }

        // check if buttons were clicked to randomize the pattern
        auto ButtonBTriggered = gui_params.wasButtonClicked("Random B");
        if (ButtonBTriggered) {
            latent_B = torch::randn({ 1, 128 });
            CustomPresetData->tensor("latent_B", latent_B);
            changed = true;
            displayPatternAt(latent_B, "MidiVisualizerB");

        }

        // check if snap here button was clicked
        auto ButtonSnapHereBTriggered = gui_params.wasButtonClicked("Snap To B");
        if (ButtonSnapHereBTriggered) {
            latent_B = latent_vector;
            CustomPresetData->tensor("latent_B", latent_B);
            gui_params.setValueFor("Interpolate", 1.0f);
            gui_params.setValueFor("Follow", 0.0f);
            changed = true;
            displayPatternAt(latent_B, "MidiVisualizerB");
            cout << "Snap to B Pressed" << endl;
        }

        // get interpolate slider value if changed
        if (gui_params.wasParamUpdated("Interpolate")) {
            interpolate_slider_value = gui_params.getValueFor("Interpolate");
            changed = true;
        }

        // get interpolate follow value if changed
        if (gui_params.wasParamUpdated("Follow")) {
            follow_slider_value = gui_params.getValueFor("Follow");
            changed = true;
        }

        // re-calculates the latent vector if any of the above changed
        if (changed || new_preset || groove_re_encoded) {

            // use interpolate slider value to interpolate between A and B
            latent_vector = (1.0f - interpolate_slider_value) * latent_A + interpolate_slider_value * latent_B;

            // use follow slider value to interpolate between A and B
            latent_vector = (1 - follow_slider_value) * latent_vector + follow_slider_value * latent_g;

            return true;
        }

        return false;

    }


    bool checkTemperature() {

        if (gui_params.wasParamUpdated("Uncertainty")) {
            auto val = gui_params.getValueFor("Uncertainty");
            if (val <= 1.0f) {
                temperature = (float) val;
            } else {
                temperature = float(1.0f + (val - 1.0f) * 4.0f);
            }
            return true;
        } else {
            return false;
        }

    }
    // update per voice midi mapping
    bool updateVoiceMapping() {
        bool changed = false;

        // --------------------- Voice Map ---------------------
        if (gui_params.wasParamUpdated("Kick")) {
            voiceMap[0] = int(gui_params.getValueFor("Kick"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("Snare")) {
            voiceMap[1] = int(gui_params.getValueFor("Snare"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("ClosedHat")) {
            voiceMap[2] = int(gui_params.getValueFor("ClosedHat"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("OpenHat")) {
            voiceMap[3] = int(gui_params.getValueFor("OpenHat"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("LowTom")) {
            voiceMap[4] = int(gui_params.getValueFor("LowTom"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("MidTom")) {
            voiceMap[5] = int(gui_params.getValueFor("MidTom"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("HighTom")) {
            voiceMap[6] = int(gui_params.getValueFor("HighTom"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("Crash")) {
            voiceMap[7] = int(gui_params.getValueFor("Crash"));
            changed = true;
        }
        if (gui_params.wasParamUpdated("Ride")) {
            voiceMap[8] = int(gui_params.getValueFor("Ride"));
            changed = true;
        }

        return changed;
    }

    // utility for mapping a single pot value to a max count/thresh of a single voice
    static juce::Point<float> mapDensitySlider(float slider_value) {

        juce::Point<float> return_value;
        juce::Point<float> point1 = {0.0f, 0.99};   // slider = 0
        juce::Point<float> point2 = {32, 0.5};      // slider = 1
        juce::Point<float> point3 = {32, 0.02};     // slider = 2

        if (slider_value < 1.0f) {
            return_value = point1 + (point2 - point1) * slider_value;
        } else if (slider_value >= 1.0f) {
            return_value = point2 + (point3 - point2) * (slider_value - 1.0f);
        }

        return return_value;
    }

    // update voice thresholds and max counts per voice
    bool updatePerVoiceSamplingParams(){
        bool changed = false;
        if (gui_params.wasParamUpdated("Generation Quantization")) {
            generation_off_quantizer_val = gui_params.getValueFor("Generation Quantization");
            changed = true;
        }

        if (gui_params.wasParamUpdated("K Den")) {
            auto val = gui_params.getValueFor("K Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[0] = mapped.getX();
            voice_thresholds[0] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("S Den"))
        {
            auto val = gui_params.getValueFor("S Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[1] = mapped.getX();
            voice_thresholds[1] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("CH Den"))
        {
            auto val = gui_params.getValueFor("CH Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[2] = mapped.getX();
            voice_thresholds[2] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("OH Den"))
        {
            auto val = gui_params.getValueFor("OH Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[3] = mapped.getX();
            voice_thresholds[3] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("Toms Den"))
        {
            auto val = gui_params.getValueFor("Toms Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[4] = mapped.getX();
            max_counts_allowed[5] = mapped.getX();
            max_counts_allowed[6] = mapped.getX();
            voice_thresholds[4] = mapped.getY();
            voice_thresholds[5] = mapped.getY();
            voice_thresholds[6] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("Crash Den"))
        {
            auto val = gui_params.getValueFor("Crash Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[7] = mapped.getX();
            voice_thresholds[7] = mapped.getY();
            changed = true;
        }
        if (gui_params.wasParamUpdated("Ride Den"))
        {
            auto val = gui_params.getValueFor("Ride Den");
            auto mapped = mapDensitySlider(val);
            max_counts_allowed[8] = mapped.getX();
            voice_thresholds[8] = mapped.getY();
            changed = true;
        }

        return changed;
    }

    // update any variables that impact the voice map
    bool updateVelocityScalingMask() {

        bool changed = false;

        // --------------------- Voice Thresholds / Max Counts / Velocities ---------------------
        // get voice thresholds if changed
        if (gui_params.wasParamUpdated("K Vel")) {
            auto vel = gui_params.getValueFor("K Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 0},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("S Vel")) {
            auto vel = gui_params.getValueFor("S Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 1},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("CH Vel")) {
            auto vel = gui_params.getValueFor("CH Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 2},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("OH Vel")) {
            auto vel = gui_params.getValueFor("OH Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 3},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("Toms Vel")) {
            auto vel = gui_params.getValueFor("Toms Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), torch::indexing::Slice(4, 7)},
                torch::ones({32, 3}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("Crash Vel")) {
            auto vel = gui_params.getValueFor("Crash Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 7},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }
        if (gui_params.wasParamUpdated("Ride Vel")) {
            auto vel = gui_params.getValueFor("Ride Vel");
            velocity_mask.index_put_(
                {torch::indexing::Slice(), torch::indexing::Slice(), 8},
                torch::ones({32}, torch::kFloat32) * vel);
            changed = true;
        }

        return changed;
    }

    void decodeLatent(at::Tensor& latent_v, at::Tensor& return_h, at::Tensor& return_v, at::Tensor& return_o) {
        // Prepare above for inference
        std::vector<torch::jit::IValue> inputs;
        inputs.emplace_back(latent_v);
        inputs.emplace_back(voice_thresholds);
        inputs.emplace_back(max_counts_allowed);
        inputs.emplace_back(sampling_mode);
        inputs.emplace_back(temperature);

        // Get the scripted method
        auto sample_method = model.get_method("sample");

        // Run inference
        auto output = sample_method(inputs);

        // Extract the generated tensors from the output
        return_h = output.toTuple()->elements()[0].toTensor();
        return_v = output.toTuple()->elements()[1].toTensor();
        return_o = output.toTuple()->elements()[2].toTensor();

        /*// Extract the generated tensors from the output
        return_h = torch::zeros({1, 32, 9}, torch::kFloat32);
        return_h = output.toTuple()->elements()[3].toTensor(); // get logits first
        return_v = output.toTuple()->elements()[1].toTensor();
        return_o = output.toTuple()->elements()[2].toTensor();

        for (int j = 0; j < 9; j++) {
            // get the max count for this voice (only above threshold)
            auto max_count = max_counts_allowed[j];
            auto threshold = voice_thresholds[j];

        }

        for(int64_t ix = 0; ix < voice_thresholds.size(0); ++ix) {
            auto thres = voice_thresholds[ix].item<float>(); // Assuming voice_thresholds is a tensor of floats
            auto max_count = max_counts_allowed[ix].item<int64_t>(); // Assuming voice_max_count_allowed is a tensor of int64

            // Get the top 'max_count' values and their indices from '_h' in the dimension 1
            auto topk = return_h.index({"...", torch::indexing::Slice(), ix}).topk(max_count, 1);
            auto max_indices = std::get<1>(topk);

            // Update 'h' with values from '_h' where the max_indices are located
            return_h.index_put_({"...", max_indices, ix}, return_h.index({"...", max_indices, ix}));

            // Apply the threshold to 'h'
            auto mask = return_h.index({"...", torch::indexing::Slice(), ix}) > thres;
            return_h.index_put_({"...", torch::indexing::Slice(), ix}, torch::where(mask, 1, 0).to(return_h.dtype()));
        }*/
    }

    // extracts the generated pattern into a PlaybackSequence
    void preparePlaybackSequence() {
        if (!playback_hits.sizes().empty()) // check if any hits are available
        {
            // clear playback sequence
            playbackSequence.clear();

            // iterate through all voices, and time steps
            int batch_ix = 0;
            for (int step_ix = 0; step_ix < 32; step_ix++)
            {
                for (int voice_ix = 0; voice_ix < 9; voice_ix++)
                {

                    // check if the voice is active at this time step
                    if (playback_hits[batch_ix][step_ix][voice_ix].item<float>() > 0.5)
                    {
                        auto midi_num = voiceMap[voice_ix];
                        auto velocity = playback_velocities[batch_ix][step_ix][voice_ix].item<float>();
                        velocity = velocity * velocity_mask[batch_ix][step_ix][voice_ix].item<float>();
                        velocity = std::clamp(velocity, 0.0f, 1.0f);
                        auto offset =
                            playback_offsets[batch_ix][step_ix][voice_ix].item<float>() * (1.0 - generation_off_quantizer_val);
                        // we are going to convert the onset time to a ratio of quarter notes
                        auto time = (step_ix + offset) * 0.25f;
                        auto duration = 0.1f;

                        if (time < 0.0f) { time += 8.0f;}
                        if (velocity > 0.0f) {
                            playbackSequence.addNoteWithDuration(
                                10, midi_num, velocity, time, duration);
                        }

                    }
                }
            }
        }
    }

    // prepares the playback policy
    void preparePlaybackPolicy() {
        // Specify the playback policy
        playbackPolicy.SetPlaybackPolicy_RelativeToAbsoluteZero();
        playbackPolicy.SetTimeUnitIsPPQ();
        playbackPolicy.SetOverwritePolicy_DeleteAllEventsInPreviousStreamAndUseNewStream(true);
        playbackPolicy.ActivateLooping(8);
    }

    // ---------------------- Visualization Utils ----------------------
    void displayGroove() {
        midiVisualizersData->clear_visualizer_data("MidiVisualizerGroove");
        for (int i = 0; i < 32; i++) {
            if (groove_hits[0][i][0].item<float>() > 0.5) {
                auto vel = groove_velocities_scaled[0][i][0].item<float>();
                auto offset = groove_offsets_scaled[0][i][0].item<float>();
                auto time = (i + offset) * 0.25f;
                if (time < 0.0f) { time += 8.0f;}
                if (vel > 0.02f) {
                    midiVisualizersData->displayNoteWithDuration("MidiVisualizerGroove", 32, vel, time, 0.1f);
                }
            }
        }
    }

    void displayPatternAt(at::Tensor& latent_v, string visualizer_name) {
        decodeLatent(latent_v, display_hits, display_velocities, display_offsets);
        display_offsets_scaled = display_offsets * (1.0 - generation_off_quantizer_val);
        midiVisualizersData->clear_visualizer_data(visualizer_name);

        for (int i = 0; i < 32; i++) {
            for (int j = 0; j < 9; j++) {
                if (display_hits[0][i][j].item<float>() > 0.5) {
                    auto vel = display_velocities[0][i][j].item<float>();
                    vel = vel * velocity_mask[0][i][j].item<float>();
                    vel = std::clamp(vel, 0.0f, 1.0f);
                    auto offset = display_offsets_scaled[0][i][j].item<float>();
                    auto time = (i + offset) * 0.25f;
                    if (time < 0.0f) { time += 8.0f;}
                    if (vel > 0.02f)
                    {
                        midiVisualizersData->displayNoteWithDuration(
                            visualizer_name, display_voice_maps[j], vel, time, 0.125f);
                    }
                }
            }
        }
    }

    void updateAllDisplayPatterns() {
        displayPatternAt(latent_A, "MidiVisualizerA");
        displayPatternAt(latent_B, "MidiVisualizerB");
        displayPatternAt(latent_g, "MidiVisualizerGroove2Drum");
    }

    // ---------------------- Utility Functions ----------------------
    // maps the playhead position to a time step
    static int mapPPQToTimeStep(double phead_) {
       /* step 0: 0.0 - 0.125 || 7.875 - 8.0
        * step 1: 0.125 - .375
        * step 2: 0.375 - 0.625
        * ...
        * step 31: 7.625 - 7.875
        * */
        phead_ = fmod(phead_, 8.0f);
        if ( 0.125f < phead_ && phead_ < 7.875f) {
            phead_ = phead_ - 0.125f;
            return int(phead_ / 0.25f) + 1;
        } else {
            return 0;
        }
    }
};